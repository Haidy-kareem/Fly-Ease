# ✈ SkyBook — Flight Booking System

## Fixed & Redesigned from Original Project

### Bugs Fixed
- **Hardcoded data paths** → now uses relative paths from working directory
- **User.toString() syntax error** → raw tab literal causing compile failure
- **BookingSystem** → fixed `DATA_PATH` removal, `searchFlights` now returns results for GUI
- **Missing GUI helper methods** → added `getAllFlights()`, `getAllBookings()`, `getCustomerBookings()`, `getAllUsers()`, `getReportString()`
- **Payment method check** → original checked for "Bank" but GUI passes "Bank Transfer"; now consistent
- **`fromFileString` robustness** → more lenient parsing (parts.length >= N instead of == N)
- **Register panel** → role-specific fields (commission rate) now show/hide correctly

### How to Run
```bash
cd path/to/project
chmod +x run.sh
./run.sh
```

### Test Accounts (preloaded)
| Username     | Password    | Role          |
|-------------|-------------|---------------|
| testCust1   | Password123 | Customer      |
| admin       | Admin123    | Administrator |
| agent1      | Agent123    | Agent         |

### Sample Flights (preloaded)
| ID | Flight | Route              | Type          |
|----|--------|-------------------|---------------|
| 1  | FL001  | CAI → DXB         | International |
| 2  | FL002  | CAI → LHR         | International |
| 3  | DOM001 | CAI → HRG         | Domestic      |

### Project Structure
```
flight_fixed/
├── run.sh              ← compile & run
├── compile.sh          ← compile only
├── data/               ← persistent data files
│   ├── users.txt
│   ├── flights.txt
│   ├── bookings.txt
│   └── passengers.txt
└── oopflightbookingsystem/
    └── src/
        ├── Gui.java           ←Complete redesign
        ├── Main.java          ← Fixed launcher
        ├── BookingSystem.java ← Fixed + extended
        ├── User.java          ← Fixed
        ├── Customer.java      ← Fixed
        ├── Agent.java         ← Fixed
        ├── Administrator.java ← Fixed
        ├── Flight.java
        ├── DomesticFlight.java
        ├── InternationalFlight.java
        ├── Booking.java
        ├── Passenger.java
        ├── Payment.java
        └── FileManager.java
```
